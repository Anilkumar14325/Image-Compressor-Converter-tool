import { Helmet } from "react-helmet";
import { Header } from "@/components/Header";
import { AdPlaceholder } from "@/components/AdPlaceholder";
import { CalculatorTabs } from "@/components/calculator/CalculatorTabs";
import { QuickTips } from "@/components/calculator/QuickTips";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>CalcPro - Online Calculator, GST & Percentage Calculator</title>
        <meta name="description" content="Free online calculator with standard, percentage, and GST calculation tools. Easy to use and mobile-friendly." />
        <meta name="keywords" content="Online Calculator, GST Calculator, Percentage Calculator, Tax Calculator, Discount Calculator" />
      </Helmet>
      
      <div className="min-h-screen max-w-screen-xl mx-auto px-4 py-8 md:px-6 flex flex-col">
        <Header />
        
        {/* Top Banner Ad (Mobile-friendly) */}
        <AdPlaceholder type="banner" />
        
        <main className="flex flex-col lg:flex-row gap-6 flex-1 mt-6">
          <div className="flex-1 lg:flex-grow-2">
            {/* Calculator Container */}
            <CalculatorTabs />
            
            {/* Below Calculator Ad Space */}
            <div className="mt-6">
              <AdPlaceholder type="below-calculator" />
            </div>
          </div>
          
          {/* Sidebar (Desktop View) */}
          <div className="w-full lg:w-80 order-first lg:order-last">
            {/* Sidebar Ad Space */}
            <div className="sticky top-4">
              <AdPlaceholder type="sidebar" />
            </div>
            
            {/* Quick Tips Section */}
            <QuickTips />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}
