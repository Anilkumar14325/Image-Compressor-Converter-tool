// Utility functions for calculator operations

/**
 * Safely evaluate a mathematical expression
 * @param expression The expression to evaluate
 * @returns The result of the evaluation or an error message
 */
export function evaluateExpression(expression: string): { result: number | null; error: string | null } {
  try {
    // Replace UI symbols with JavaScript operators
    const sanitizedExpression = expression
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/%/g, '/100');
      
    // Basic safety check to ensure only valid arithmetic
    if (!/^[\d+\-*/().%\s]+$/.test(sanitizedExpression)) {
      return { result: null, error: 'Invalid expression' };
    }
    
    // Using Function to evaluate is safer than eval but still needs sanitization
    const result = new Function(`return ${sanitizedExpression}`)();
    
    if (typeof result !== 'number' || !isFinite(result)) {
      return { result: null, error: 'Invalid result' };
    }
    
    return { result, error: null };
  } catch (error) {
    return { result: null, error: 'Calculation error' };
  }
}

/**
 * Format a number with currency symbol
 * @param value The number to format
 * @param currencySymbol The currency symbol to use
 * @returns Formatted currency string
 */
export function formatCurrency(value: number, currencySymbol: string = '₹'): string {
  return `${currencySymbol}${value.toFixed(2)}`;
}

/**
 * Calculate percentage of a number
 * @param percent The percentage value
 * @param total The total value
 * @returns The calculated percentage amount
 */
export function calculatePercentage(percent: number, total: number): number {
  return (percent / 100) * total;
}

/**
 * Calculate GST
 * @param amount The base amount
 * @param rate The GST rate (e.g., 18 for 18%)
 * @param isInclusive Whether GST is already included in the amount
 * @returns Object containing original amount, GST amount, and total
 */
export function calculateGST(amount: number, rate: number, isInclusive: boolean): {
  originalAmount: number;
  gstAmount: number;
  totalAmount: number;
} {
  if (isInclusive) {
    // GST is included in the amount
    const divisor = 1 + (rate / 100);
    const originalAmount = amount / divisor;
    const gstAmount = amount - originalAmount;
    
    return {
      originalAmount,
      gstAmount,
      totalAmount: amount,
    };
  } else {
    // GST needs to be added to the amount
    const gstAmount = (amount * rate) / 100;
    
    return {
      originalAmount: amount,
      gstAmount,
      totalAmount: amount + gstAmount,
    };
  }
}
