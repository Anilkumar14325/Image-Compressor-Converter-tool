import { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { StandardCalculator } from "./StandardCalculator";
import { PercentageCalculator } from "./PercentageCalculator";
import { GSTCalculator } from "./GSTCalculator";

export function CalculatorTabs() {
  const [activeTab, setActiveTab] = useState("standard");

  return (
    <Tabs defaultValue="standard" value={activeTab} onValueChange={setActiveTab} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
      <TabsList className="w-full grid grid-cols-3 border-b border-gray-200 dark:border-gray-700 rounded-none h-auto">
        <TabsTrigger 
          value="standard" 
          className="py-4 data-[state=active]:text-blue-600 data-[state=active]:dark:text-blue-400 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:dark:border-blue-400 data-[state=active]:shadow-none rounded-none"
        >
          Standard
        </TabsTrigger>
        <TabsTrigger 
          value="percentage" 
          className="py-4 data-[state=active]:text-blue-600 data-[state=active]:dark:text-blue-400 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:dark:border-blue-400 data-[state=active]:shadow-none rounded-none"
        >
          Percentage
        </TabsTrigger>
        <TabsTrigger 
          value="gst" 
          className="py-4 data-[state=active]:text-blue-600 data-[state=active]:dark:text-blue-400 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:dark:border-blue-400 data-[state=active]:shadow-none rounded-none"
        >
          GST
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="standard" className="p-0 m-0">
        <StandardCalculator />
      </TabsContent>
      
      <TabsContent value="percentage" className="p-0 m-0">
        <PercentageCalculator />
      </TabsContent>
      
      <TabsContent value="gst" className="p-0 m-0">
        <GSTCalculator />
      </TabsContent>
    </Tabs>
  );
}
