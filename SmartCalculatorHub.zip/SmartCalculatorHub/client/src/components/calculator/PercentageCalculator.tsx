import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { math } from "../../main";
import { motion } from "framer-motion";

type PercentageMode = 'find' | 'increase-decrease';

export function PercentageCalculator() {
  const [mode, setMode] = useState<PercentageMode>('find');
  const [percentValue, setPercentValue] = useState<string>('15');
  const [totalValue, setTotalValue] = useState<string>('200');
  const [baseValue, setBaseValue] = useState<string>('100');
  const [increaseDecreasePercent, setIncreaseDecreasePercent] = useState<string>('10');
  const [result, setResult] = useState<string>('30');
  const [explanation, setExplanation] = useState<string>('15% of 200 = 30');

  const calculatePercentage = () => {
    try {
      if (mode === 'find') {
        // Calculate X% of Y
        const percent = parseFloat(percentValue) || 0;
        const total = parseFloat(totalValue) || 0;
        const calculatedResult = (percent / 100) * total;
        
        setResult(calculatedResult.toFixed(2));
        setExplanation(`${percent}% of ${total} = ${calculatedResult.toFixed(2)}`);
      } else {
        // Calculate increase/decrease by X%
        const base = parseFloat(baseValue) || 0;
        const percent = parseFloat(increaseDecreasePercent) || 0;
        const change = (base * percent) / 100;
        const newValue = base + change;
        
        setResult(newValue.toFixed(2));
        setExplanation(`${base} + ${percent}% (${change.toFixed(2)}) = ${newValue.toFixed(2)}`);
      }
    } catch (error) {
      setResult('Error');
      setExplanation('Invalid calculation');
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Mode Switcher */}
      <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-lg">
        <Button
          variant={mode === 'find' ? 'default' : 'ghost'}
          className={`flex-1 py-2 px-3 rounded-md ${
            mode === 'find' 
              ? 'bg-white dark:bg-gray-800 shadow-sm text-gray-800 dark:text-white' 
              : 'text-gray-600 dark:text-gray-300 bg-transparent'
          }`}
          onClick={() => setMode('find')}
        >
          Find Percentage
        </Button>
        <Button
          variant={mode === 'increase-decrease' ? 'default' : 'ghost'}
          className={`flex-1 py-2 px-3 rounded-md ${
            mode === 'increase-decrease' 
              ? 'bg-white dark:bg-gray-800 shadow-sm text-gray-800 dark:text-white' 
              : 'text-gray-600 dark:text-gray-300 bg-transparent'
          }`}
          onClick={() => setMode('increase-decrease')}
        >
          Increase/Decrease
        </Button>
      </div>
      
      {/* Form */}
      <div className="space-y-3">
        {mode === 'find' ? (
          <>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">What is</Label>
              <div className="relative">
                <Input
                  type="number"
                  className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                  placeholder="e.g. 15"
                  value={percentValue}
                  onChange={(e) => setPercentValue(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <span className="text-gray-500 dark:text-gray-400">%</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">of</Label>
              <Input
                type="number"
                className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                placeholder="e.g. 200"
                value={totalValue}
                onChange={(e) => setTotalValue(e.target.value)}
              />
            </div>
          </>
        ) : (
          <>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">Base Value</Label>
              <Input
                type="number"
                className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                placeholder="e.g. 100"
                value={baseValue}
                onChange={(e) => setBaseValue(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Percentage Change
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                  placeholder="e.g. 10"
                  value={increaseDecreasePercent}
                  onChange={(e) => setIncreaseDecreasePercent(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <span className="text-gray-500 dark:text-gray-400">%</span>
                </div>
              </div>
              <div className="flex gap-2 mt-1">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-green-600"
                  onClick={() => {
                    // Ensure the percentage is positive for increase
                    const value = Math.abs(parseFloat(increaseDecreasePercent) || 0);
                    setIncreaseDecreasePercent(value.toString());
                  }}
                >
                  Increase
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600"
                  onClick={() => {
                    // Ensure the percentage is negative for decrease
                    const value = -Math.abs(parseFloat(increaseDecreasePercent) || 0);
                    setIncreaseDecreasePercent(value.toString());
                  }}
                >
                  Decrease
                </Button>
              </div>
            </div>
          </>
        )}
        
        <Button
          className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg font-medium transition-colors"
          onClick={calculatePercentage}
        >
          Calculate
        </Button>
        
        <motion.div
          className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg"
          initial={{ opacity: 0.8, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-lg font-medium text-gray-800 dark:text-white">Result</div>
          <div className="text-2xl font-semibold text-blue-600 dark:text-blue-400 mt-1">
            {result}
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-300 mt-2">
            {explanation}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
