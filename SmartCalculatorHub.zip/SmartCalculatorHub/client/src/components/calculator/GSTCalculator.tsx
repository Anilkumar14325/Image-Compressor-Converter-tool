import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";

const GST_RATES = [5, 12, 18, 28];

type GstMode = 'add' | 'remove';

export function GSTCalculator() {
  const [selectedRate, setSelectedRate] = useState<number>(5);
  const [customRate, setCustomRate] = useState<string>("5");
  const [amount, setAmount] = useState<string>("1000");
  const [mode, setMode] = useState<GstMode>('add');
  
  // Results
  const [originalAmount, setOriginalAmount] = useState<string>("₹1,000.00");
  const [gstAmount, setGstAmount] = useState<string>("₹50.00");
  const [totalAmount, setTotalAmount] = useState<string>("₹1,050.00");

  const handleRateSelection = (rate: number) => {
    setSelectedRate(rate);
    setCustomRate(rate.toString());
  };

  const handleCustomRateChange = (value: string) => {
    setCustomRate(value);
    const numValue = parseFloat(value);
    if (!isNaN(numValue) && GST_RATES.includes(numValue)) {
      setSelectedRate(numValue);
    } else {
      setSelectedRate(-1); // Custom rate not in presets
    }
  };

  const calculateGst = () => {
    try {
      const amountValue = parseFloat(amount) || 0;
      const rateValue = parseFloat(customRate) || 0;
      
      if (mode === 'add') {
        // Add GST to amount
        const gstValue = (amountValue * rateValue) / 100;
        const total = amountValue + gstValue;
        
        setOriginalAmount(`₹${amountValue.toFixed(2)}`);
        setGstAmount(`₹${gstValue.toFixed(2)}`);
        setTotalAmount(`₹${total.toFixed(2)}`);
      } else {
        // Remove GST from amount (amount is inclusive of GST)
        const divisor = 1 + (rateValue / 100);
        const originalValue = amountValue / divisor;
        const gstValue = amountValue - originalValue;
        
        setOriginalAmount(`₹${originalValue.toFixed(2)}`);
        setGstAmount(`₹${gstValue.toFixed(2)}`);
        setTotalAmount(`₹${amountValue.toFixed(2)}`);
      }
    } catch (error) {
      setOriginalAmount("Error");
      setGstAmount("Error");
      setTotalAmount("Error");
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* GST Rate Selection */}
      <div className="space-y-2">
        <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300">GST Rate</Label>
        <div className="grid grid-cols-4 gap-2">
          {GST_RATES.map((rate) => (
            <Button
              key={rate}
              className={`py-2 px-3 rounded-md text-sm font-medium ${
                selectedRate === rate
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white"
              }`}
              onClick={() => handleRateSelection(rate)}
            >
              {rate}%
            </Button>
          ))}
        </div>
        <div className="flex items-center mt-2">
          <Input
            type="number"
            className="w-20 p-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-white text-center"
            placeholder="Custom"
            min="0"
            max="100"
            value={customRate}
            onChange={(e) => handleCustomRateChange(e.target.value)}
          />
          <span className="ml-2 text-gray-600 dark:text-gray-300">Custom Rate (%)</span>
        </div>
      </div>
      
      {/* GST Calculation Type */}
      <div className="space-y-2">
        <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Calculation Type</Label>
        <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-lg">
          <Button
            variant={mode === 'add' ? 'default' : 'ghost'}
            className={`flex-1 py-2 px-3 rounded-md ${
              mode === 'add' 
                ? 'bg-white dark:bg-gray-800 shadow-sm text-gray-800 dark:text-white' 
                : 'text-gray-600 dark:text-gray-300 bg-transparent'
            }`}
            onClick={() => setMode('add')}
          >
            Add GST
          </Button>
          <Button
            variant={mode === 'remove' ? 'default' : 'ghost'}
            className={`flex-1 py-2 px-3 rounded-md ${
              mode === 'remove' 
                ? 'bg-white dark:bg-gray-800 shadow-sm text-gray-800 dark:text-white' 
                : 'text-gray-600 dark:text-gray-300 bg-transparent'
            }`}
            onClick={() => setMode('remove')}
          >
            Remove GST
          </Button>
        </div>
      </div>
      
      {/* Amount Input */}
      <div className="space-y-2">
        <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Amount</Label>
        <Input
          type="number"
          className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
          placeholder="Enter amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
      </div>
      
      <Button
        className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg font-medium transition-colors"
        onClick={calculateGst}
      >
        Calculate
      </Button>
      
      {/* Results */}
      <motion.div
        className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg space-y-2"
        initial={{ opacity: 0.8, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-300">Original Amount:</span>
          <span className="font-medium text-gray-800 dark:text-white">{originalAmount}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-300">GST Amount ({customRate}%):</span>
          <span className="font-medium text-gray-800 dark:text-white">{gstAmount}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-300">Total Amount:</span>
          <span className="font-semibold text-blue-600 dark:text-blue-400 text-lg">{totalAmount}</span>
        </div>
      </motion.div>
    </div>
  );
}
