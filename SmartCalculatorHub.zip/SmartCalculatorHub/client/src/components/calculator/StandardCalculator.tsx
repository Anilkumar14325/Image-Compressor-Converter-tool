import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { math } from "../../main";

// Define button types
type ButtonType = 'number' | 'operator' | 'equals' | 'clear' | 'parenthesis' | 'percentage';

// Interface for calculator buttons
interface CalcButton {
  label: string;
  value: string;
  type: ButtonType;
}

// Define all calculator buttons
const calculatorButtons: CalcButton[] = [
  { label: 'C', value: 'C', type: 'clear' },
  { label: '(', value: '(', type: 'parenthesis' },
  { label: ')', value: ')', type: 'parenthesis' },
  { label: '÷', value: '/', type: 'operator' },
  { label: '7', value: '7', type: 'number' },
  { label: '8', value: '8', type: 'number' },
  { label: '9', value: '9', type: 'number' },
  { label: '×', value: '*', type: 'operator' },
  { label: '4', value: '4', type: 'number' },
  { label: '5', value: '5', type: 'number' },
  { label: '6', value: '6', type: 'number' },
  { label: '-', value: '-', type: 'operator' },
  { label: '1', value: '1', type: 'number' },
  { label: '2', value: '2', type: 'number' },
  { label: '3', value: '3', type: 'number' },
  { label: '+', value: '+', type: 'operator' },
  { label: '%', value: '%', type: 'percentage' },
  { label: '0', value: '0', type: 'number' },
  { label: '.', value: '.', type: 'number' },
  { label: '=', value: '=', type: 'equals' },
];

export function StandardCalculator() {
  const [input, setInput] = useState<string>('');
  const [result, setResult] = useState<string>('0');
  const [calculated, setCalculated] = useState<boolean>(false);

  // Handle key press input
  const handleKeyInput = (key: CalcButton) => {
    if (calculated && (key.type === 'number' || key.type === 'parenthesis')) {
      setInput(key.value);
      setCalculated(false);
    } else if (key.type === 'clear') {
      setInput('');
      setResult('0');
      setCalculated(false);
    } else if (key.type === 'equals') {
      try {
        if (input) {
          // Replace % with /100 for percentage calculations
          let expression = input.replace(/%/g, "/100");
          const evalResult = math.evaluate(expression);
          const formattedResult = typeof evalResult === 'number' && !Number.isInteger(evalResult) 
            ? evalResult.toFixed(2) 
            : evalResult.toString();
          
          setResult(formattedResult);
          setCalculated(true);
        }
      } catch (error) {
        setResult('Error');
      }
    } else if (key.type === 'percentage') {
      setInput(prev => prev + key.label);
    } else {
      // Add the key to the input
      setInput(prev => {
        // Only allow one decimal point per number
        if (key.value === '.' && prev.split(/[-+*/]/).pop()?.includes('.')) {
          return prev;
        }
        
        // For operators, don't allow consecutive operators
        if (key.type === 'operator' && /[-+*/]$/.test(prev)) {
          return prev.slice(0, -1) + key.value;
        }
        
        return prev + key.value;
      });
    }
  };

  // Calculate display for the preview
  const getDisplayInput = () => {
    return input.replace(/\*/g, '×').replace(/\//g, '÷');
  };

  return (
    <div className="p-4">
      {/* Calculator Display */}
      <div className="mb-4 p-3 bg-gray-100 dark:bg-gray-900 rounded-lg">
        <div className="text-right text-gray-500 dark:text-gray-400 text-sm h-6 font-mono overflow-hidden">
          {getDisplayInput()}
        </div>
        <div className="text-right text-3xl font-semibold font-mono text-gray-900 dark:text-white h-10 overflow-hidden">
          {result}
        </div>
      </div>
      
      {/* Calculator Keypad */}
      <div className="grid grid-cols-4 gap-2">
        {calculatorButtons.map((button, index) => {
          // Determine button styling based on type
          let buttonClass = "";
          
          switch (button.type) {
            case 'number':
              buttonClass = "bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-800 dark:text-white border border-gray-200 dark:border-gray-700";
              break;
            case 'operator':
              buttonClass = "bg-amber-500 hover:bg-amber-600 text-white";
              break;
            case 'equals':
              buttonClass = "bg-blue-600 hover:bg-blue-700 text-white";
              break;
            case 'clear':
            case 'parenthesis':
            case 'percentage':
              buttonClass = "bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white";
              break;
          }
          
          return (
            <Button
              key={index}
              onClick={() => handleKeyInput(button)}
              className={`${buttonClass} p-3 rounded-lg text-lg font-medium transition-colors h-auto`}
              variant="ghost"
            >
              {button.label}
            </Button>
          );
        })}
      </div>
    </div>
  );
}
