import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function QuickTips() {
  return (
    <Card className="mt-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
      <CardHeader className="p-4 bg-blue-600 text-white">
        <CardTitle className="text-lg font-semibold">Calculator Tips</CardTitle>
      </CardHeader>
      <CardContent className="p-4 space-y-3">
        <div className="space-y-1">
          <h3 className="font-medium text-gray-800 dark:text-white">Standard Calculator</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Use parentheses ( ) to group operations and follow BODMAS/PEMDAS rule.
          </p>
        </div>
        <div className="space-y-1">
          <h3 className="font-medium text-gray-800 dark:text-white">Percentage Calculator</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            To find a discount, calculate what percentage of the original price is the discounted amount.
          </p>
        </div>
        <div className="space-y-1">
          <h3 className="font-medium text-gray-800 dark:text-white">GST Calculator</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            For inclusive GST, the original price already includes the tax amount.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
