import { ThemeToggle } from "./ThemeToggle";
import { CalculatorIcon } from "lucide-react";

export function Header() {
  return (
    <header className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-2">
        <CalculatorIcon className="text-blue-600 dark:text-blue-400 h-7 w-7" />
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">CalcPro</h1>
      </div>
      <ThemeToggle />
    </header>
  );
}
