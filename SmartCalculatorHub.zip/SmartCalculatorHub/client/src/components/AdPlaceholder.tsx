type AdPlaceholderProps = {
  type: "banner" | "below-calculator" | "sidebar";
};

export function AdPlaceholder({ type }: AdPlaceholderProps) {
  const getAdSize = () => {
    switch (type) {
      case "banner":
        return { height: "h-16", text: "Ad Space (728×90)" };
      case "below-calculator":
        return { height: "h-16", text: "Ad Space (728×90)" };
      case "sidebar":
        return { height: "h-64", text: "Ad Space (300×600)" };
      default:
        return { height: "h-16", text: "Advertisement" };
    }
  };

  const { height, text } = getAdSize();

  return (
    <div className={`w-full bg-gray-100 dark:bg-gray-800 rounded-lg p-3 text-center`}>
      <div className="text-sm text-gray-500 dark:text-gray-400">Advertisement</div>
      <div className={`${height} flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded`}>
        <span className="text-gray-500 dark:text-gray-400">{text}</span>
      </div>
    </div>
  );
}
