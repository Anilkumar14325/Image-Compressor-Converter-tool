export function Footer() {
  return (
    <footer className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
      <p>© {new Date().getFullYear()} CalcPro - All rights reserved</p>
      <div className="mt-2 flex justify-center space-x-4">
        <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400">Privacy Policy</a>
        <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400">Terms of Use</a>
        <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400">Contact Us</a>
      </div>
    </footer>
  );
}
